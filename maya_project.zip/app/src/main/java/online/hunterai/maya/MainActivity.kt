package online.hunterai.maya

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.cos
import kotlin.math.sin

val Bg = Color(0xFFD9E3F5)
val Ink = Color(0xFF16204A)
val Accent = Color(0xFF3B8BFF)

fun Modifier.neu(r: Dp = 24.dp) = this
    .shadow(10.dp, RoundedCornerShape(r), ambientColor = Color(0xFFB4C3E6), spotColor = Color(0xFFB4C3E6))
    .background(Brush.verticalGradient(listOf(Color.White, Color(0xFFF0F4FF))), RoundedCornerShape(r))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MayaHome() }
    }
}

fun greetingFor(h: Int) = when (h) {
    in 0..4 -> "Abhi tak jag rahe ho,"
    in 5..11 -> "Subah bakhair,"
    in 12..16 -> "Dopahar mubarak,"
    in 17..20 -> "Shaam mubarak,"
    else -> "Raat ho gayi,"
}

@Composable
fun MayaHome() {
    var listening by remember { mutableStateOf(false) }
    val today = LocalDate.now()
    Column(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 20.dp, vertical = 36.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            RoundIcon("☰")
            Text("Maya", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Ink,
                modifier = Modifier.padding(start = 16.dp).weight(1f))
            RoundIcon("🔔")
        }
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier.fillMaxWidth().background(Color(0xFFC5D6F2), RoundedCornerShape(20.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Free mode • aaj 10:00 min baaki", fontWeight = FontWeight.Bold, color = Ink)
                Text("Saare tools ke liye license activate karo", fontSize = 13.sp, color = Ink)
            }
            Text("Activate karo", color = Accent, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Text(greetingFor(LocalTime.now().hour), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink.copy(alpha = .8f))
        Text("dost", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Orb(listening) { listening = !listening }
        }
        Text(
            if (listening) "Main sun rahi hoon, Jan..." else "Orb dabao, Maya se baat karo",
            color = Ink.copy(alpha = .7f), modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Pill("🎵 Gaane", Modifier.weight(1f))
            Pill("📖 Padhai", Modifier.weight(1f))
            Pill("✏️ Journal", Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard("Mausam", "12°", "Clear", Modifier.weight(1f))
            InfoCard("Aaj", "${today.dayOfMonth}", today.dayOfWeek.name.take(3), Modifier.weight(1f))
            InfoCard("Mood", "Pyaar", "Sab badhiya", Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier.fillMaxWidth().neu(30.dp).padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            listOf("🏠 Home", "📷 Scan", "🎤 Mic", "🧠 Yaadein", "💬 Chat").forEach {
                Text(it, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Ink)
            }
        }
    }
}

@Composable
fun RoundIcon(t: String) {
    Box(Modifier.size(46.dp).neu(23.dp), contentAlignment = Alignment.Center) { Text(t, fontSize = 18.sp) }
}

@Composable
fun Pill(t: String, m: Modifier) {
    Box(m.neu(26.dp).padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
        Text(t, fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp)
    }
}

@Composable
fun InfoCard(title: String, big: String, sub: String, m: Modifier) {
    Column(m.neu(26.dp).padding(16.dp)) {
        Text(title, fontSize = 13.sp, color = Ink.copy(alpha = .7f))
        Text(big, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text(sub, fontSize = 13.sp, color = Ink.copy(alpha = .7f))
    }
}

@Composable
fun Orb(active: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        1f, if (active) 1.15f else 1.05f,
        infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p"
    )
    val spin by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(12000, easing = LinearEasing)), label = "s"
    )
    val glow = if (active) Color(0xFF3B8BFF) else Color(0xFFE5486B)
    Canvas(Modifier.size(240.dp).clickable(onClick = onClick)) {
        val c = center
        val r = size.minDimension / 2
        drawCircle(glow.copy(alpha = .18f), r * pulse, c)
        for (i in 0 until 72) {
            rotate(i * 5f + spin / 8f, c) {
                drawLine(glow.copy(alpha = .7f), Offset(c.x, c.y - r * .78f), Offset(c.x, c.y - r * .86f), 2f)
            }
        }
        drawCircle(glow, r * .6f, c, style = Stroke(10f))
        drawCircle(Color(0xFF0A0A12), r * .55f, c)
        rotate(spin, c) {
            for (i in 0 until 40) {
                val a = i * 0.157f
                val rr = r * .5f * ((i % 7) / 7f + .2f)
                drawCircle(Color(0xFFFFB347).copy(alpha = .8f), 3f, Offset(c.x + cos(a) * rr, c.y + sin(a * 1.3f) * rr))
            }
        }
    }
}
